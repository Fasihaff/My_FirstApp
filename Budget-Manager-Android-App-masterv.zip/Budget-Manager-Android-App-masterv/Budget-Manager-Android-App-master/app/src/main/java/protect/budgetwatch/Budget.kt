package protect.budgetwatch

class Budget(val name: String, val max: Int, val current: Int)

